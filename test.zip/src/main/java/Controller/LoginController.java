package Controller;


import ch.qos.logback.core.model.Model;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class LoginController {



    @GetMapping("/Login")
    public String login(Model model) {
        return "Login";
    }

    @GetMapping("/Startseite")
    public String Startseite(Model model) {
        System.out.println("Index.HTML");

        return "startseite";
    }
}

