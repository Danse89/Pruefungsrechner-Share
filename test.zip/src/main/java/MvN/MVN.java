package MvN;

import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.ViewControllerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;


public class MVN implements WebMvcConfigurer {


//

        public void addViewControllers(ViewControllerRegistry registry) {
            // Hier kannst du zusätzliche View-Controller registrieren, wenn benötigt.

            registry.addViewController("/startseite").setViewName("Startseite");


}}